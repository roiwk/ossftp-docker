# -*- coding: utf-8 -*-

app_name = "ossftp1.0.3"
max_send_retry_times = 3
send_data_buff_size = 10 * 1024 * 1024
